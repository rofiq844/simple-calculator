var first=prompt("enter your first number");
var second=prompt("enter your first second");
// addition
var sum1=parseInt(first);
var sum2=parseInt(second);
var result=sum1+sum2;
document.write("addition  "+sum1 +" + "+sum2 +" = "+result+"<br>");
var result=sum1-sum2;
document.write("Subtraction  "+sum1 +" - "+sum2 +" = "+result+"<br>");
var result=sum1*sum2;
document.write("Multipulication  "+sum1 +" * "+sum2 +" = "+result+"<br>");
var result=sum1/sum2;
document.write("Division  "+sum1 +" / "+sum2 +" = "+result+"<br>");

document.write("point  "+ Math.floor(Math.random()*10) +"<br>");
